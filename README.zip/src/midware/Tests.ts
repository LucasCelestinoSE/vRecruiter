import { Request, Response } from "express"
export async function userJobRegister(req: Request, res: Response) {
    
    try {
       
    } catch (error) {
        
    }
}