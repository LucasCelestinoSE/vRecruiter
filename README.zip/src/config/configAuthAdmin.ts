export const jwtsecret = {
    secretJWTU : "782784uhsdfd212323423434@3456456dfhasufa324masd7628048234dfs82398742387hfsdf",
    
}