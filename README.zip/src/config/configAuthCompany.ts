export const jwtsecret = {
    secretJWTU : "782784uhsdfd234@3dfhasufamasd7628048234dfs82398742387hfsdf",
    
}