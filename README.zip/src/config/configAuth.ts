export const jwtsecret = {
    secretJWTU : "b552784670b151fa11b8974e13af9930ad68bcb403930057a635e35a1a1577dd",
    
}